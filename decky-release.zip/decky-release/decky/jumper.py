# jumper.py - Writes ~/.bashrc.d/<name> based on jumper settings

import os
from decky.db import get_setting

BASHRC_D = os.path.expanduser("~/.bashrc.d")

def write_jumper():
    """Generate and write the jumper shell file from current settings."""
    name     = get_setting("jumper_name")           or "decky"
    host     = get_setting("jumper_host")           or "d"
    timeout  = get_setting("jumper_timeout")        or "2h"
    rcmd     = get_setting("jumper_remote_cmd")     or "kssh"

    jumper_block = f"""# {name} - Jumper workflow (managed by Decky)
# DO NOT EDIT MANUALLY - changes will be overwritten by Decky Settings

# Clear stale SSH sockets
alias {name}_sock='rm -rf ~/.ssh/sockets/*'

# Fresh persistent login to shared jumpbox
{name}s() {{
    if ssh -O check shared 2>/dev/null; then
        ssh -O exit shared 2>/dev/null
    fi
    ssh shared
}}

# Interactive login (with optional command)
{name}a() {{
    local ticket=$1
    local cmd=$2
    if [ -z "$cmd" ]; then
        timeout {timeout} ssh -q {host} -t "{rcmd} $ticket" 2>/dev/null || {{ echo "Conn failed, cleaning sockets..."; {name}_sock; }}
    else
        timeout {timeout} ssh -q {host} -t "{rcmd} $ticket '$cmd'" 2>/dev/null || {{ echo "Conn failed, cleaning sockets..."; {name}_sock; }}
    fi
}}

# Jumper - ticket login or remote command execution
# Usage:
#   {name} <ticket>                        -> interactive login
#   {name} <ticket> <command>              -> run a command on the remote server
{name}() {{
    local ticket=$1
    local action=$2

    export TICKET="$ticket"

    if [ -z "$action" ]; then
        timeout {timeout} ssh -q {host} -t "{rcmd} $ticket" || {{ echo "Conn failed, cleaning sockets..."; {name}_sock; }}
    else
        shift 1
        timeout {timeout} ssh -q {host} -t "{rcmd} $ticket '$@' 2>/dev/null" 2>/dev/null || {{ echo "Conn failed, cleaning sockets..."; {name}_sock; }}
    fi
}}
"""

    scripts_block = r"""
# scripts - CLI interface to Decky one liners and recipes
scripts() {
    local name=$1
    shift
    local db="$HOME/.config/decky/decky.db"

    if [ -z "$name" ]; then
        echo "=== One Liners ==="
        sqlite3 "$db" "SELECT name, category, command FROM oneliners ORDER BY category, name" | awk -F'|' '{printf "  %-20s %-15s %s\n", $1, $2, $3}'
        echo ""
        echo "=== Recipes ==="
        sqlite3 "$db" "SELECT name FROM recipes ORDER BY name" | awk '{print "  " $0}'
        return
    fi

    # Check recipes first
    local recipe=$(sqlite3 "$db" "SELECT name FROM recipes WHERE name='$name'" 2>/dev/null)
    if [ -n "$recipe" ]; then
        sqlite3 "$db" "SELECT o.command FROM oneliners o JOIN recipe_oneliners ro ON o.id=ro.oneliner_id JOIN recipes r ON r.id=ro.recipe_id WHERE r.name='$name' ORDER BY ro.sort_order" | while IFS= read -r cmd; do
            eval "$cmd $@"
        done
        return
    fi

    # Check one liners
    local cmd=$(sqlite3 "$db" "SELECT command FROM oneliners WHERE name='$name'" 2>/dev/null)
    if [ -n "$cmd" ]; then
        # Handle --help
        if [ "$1" = "--help" ]; then
            local desc=$(sqlite3 "$db" "SELECT description FROM oneliners WHERE name='$name'" 2>/dev/null)
            echo "Usage: scripts $name"
            [ -n "$desc" ] && echo "$desc" || echo "No description available."
            return
        fi
        # Resolve {{variables}} using python3
        cmd=$(python3 -c "
import re, sys
cmd = sys.argv[1]
args = list(sys.argv[2:])
vars = list(dict.fromkeys(re.findall(r'\{\{(\w+)\}\}', cmd)))
for i, var in enumerate(vars):
    val = args[i] if i < len(args) else input(f'{var}: ')
    cmd = cmd.replace('{{' + var + '}}', val)
print(cmd)
" "$cmd" "$@")
        eval "$cmd"
        return
    fi

    echo "Error: '$name' not found in Decky."
}

# Tab completion for scripts
_scripts_completions() {
    local cur="${COMP_WORDS[COMP_CWORD]}"
    local db="$HOME/.config/decky/decky.db"
    local names=$(sqlite3 "$db" "SELECT name FROM oneliners UNION SELECT name FROM recipes ORDER BY name" 2>/dev/null)
    COMPREPLY=( $(compgen -W "${names}" -- ${cur}) )
}
complete -F _scripts_completions scripts
"""

    content = jumper_block + scripts_block

    import tempfile
    import shutil
    import subprocess

    os.makedirs(BASHRC_D, exist_ok=True)
    output_path = os.path.join(BASHRC_D, name)

    # Write to temp file and validate with bash -n
    with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    result = subprocess.run(["bash", "-n", tmp_path], capture_output=True, text=True)
    if result.returncode != 0:
        os.unlink(tmp_path)
        raise ValueError(f"Jumper syntax error:\n{result.stderr}")

    # Backup existing file
    backup_path = output_path + ".decky.bak"
    if os.path.exists(output_path):
        shutil.copy2(output_path, backup_path)

    # Write validated file
    try:
        shutil.move(tmp_path, output_path)
    except Exception as e:
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, output_path)
        raise e

    print(f"Jumper written to {output_path}")
    print(f"Run: source ~/.bashrc to activate")


def write_autostart(enable):
    """Write or remove ~/.config/autostart/decky.desktop."""
    import shutil
    autostart_dir = os.path.expanduser("~/.config/autostart")
    desktop_path = os.path.join(autostart_dir, "decky.desktop")
    python = shutil.which("python3") or "python3"
    main_path = os.path.expanduser("~/.local/share/decky/main.py")

    if enable:
        os.makedirs(autostart_dir, exist_ok=True)
        content = f"""[Desktop Entry]
Type=Application
Name=Decky
Exec=nohup {python} {main_path} &>/dev/null &
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Comment=Decky SSH and command manager
"""
        with open(desktop_path, 'w') as f:
            f.write(content)
        print(f"Autostart written to {desktop_path}")
    else:
        if os.path.exists(desktop_path):
            os.remove(desktop_path)
            print(f"Autostart removed")
