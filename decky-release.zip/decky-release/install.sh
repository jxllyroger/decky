#!/bin/bash
# Decky Installer

set -e

DECKY_SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DECKY_DEST="$HOME/.local/share/decky"
BASHRC_D="$HOME/.bashrc.d"

echo "=== Decky Installer ==="
echo ""

# --- System packages ---
echo "[1/4] Checking system packages..."
MISSING=()
for pkg in python3 sqlite3 wmctrl xdotool; do
    command -v $pkg &>/dev/null || MISSING+=($pkg)
done

if [ ${#MISSING[@]} -gt 0 ]; then
    echo "  Installing: ${MISSING[*]}"
    sudo apt install -y "${MISSING[@]}"
else
    echo "  All system packages present."
fi

# --- Python dependencies ---
echo ""
echo "[2/4] Installing Python dependencies..."
pip install pygobject pynput --break-system-packages -q
echo "  Done."

# --- Install Decky app ---
echo ""
echo "[3/4] Installing Decky to $DECKY_DEST..."
mkdir -p "$DECKY_DEST"
cp -r "$DECKY_SRC/main.py" "$DECKY_DEST/"
cp -r "$DECKY_SRC/decky" "$DECKY_DEST/"
echo "  Done."

# --- Ensure ~/.bashrc sources ~/.bashrc.d ---
echo ""
echo "[4/4] Checking ~/.bashrc..."
mkdir -p "$BASHRC_D"
if ! grep -q "bashrc.d" ~/.bashrc; then
    cat >> ~/.bashrc << 'BASHRC'

# Source ~/.bashrc.d
if [ -d ~/.bashrc.d ]; then
    for rc in ~/.bashrc.d/*; do
        if [ -f "$rc" ]; then
            . "$rc"
        fi
    done
fi
BASHRC
    echo "  Added ~/.bashrc.d sourcing to ~/.bashrc"
else
    echo "  ~/.bashrc already sources ~/.bashrc.d"
fi

echo ""
echo "=== Installation complete ==="
echo ""
echo "Start Decky:"
echo "  nohup python3 $DECKY_DEST/main.py &>/dev/null &"
echo ""
echo "Open Settings in Decky to configure your Jumper and enable autostart."
echo ""
read -p "Start Decky now? [y/N] " answer
if [[ "$answer" =~ ^[Yy]$ ]]; then
    nohup python3 "$DECKY_DEST/main.py" &>/dev/null &
    echo "Decky started. Look for the tray icon."
fi
