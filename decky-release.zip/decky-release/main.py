#!/usr/bin/env python3
from decky.tray import DeckyApp

if __name__ == "__main__":
    app = DeckyApp()
    app.run()
