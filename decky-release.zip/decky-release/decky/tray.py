# tray.py - System tray icon and right-click menu

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import signal
import threading

from decky.db import init_db, get_setting, export_data, import_data


def normalize_hotkey(hotkey):
    """Normalize hotkey string to pynput format."""
    # Convert <ctrl>k → <ctrl>+k style if missing +
    import re
    return re.sub(r'>([\w])', r'>+\1', hotkey)


class DeckyApp:
    def __init__(self):
        init_db()

        self.icon = Gtk.StatusIcon()
        self.icon.set_from_icon_name("utilities-terminal")
        self.icon.set_tooltip_text("Decky")
        self.icon.set_visible(True)
        self.icon.connect("popup-menu", self.on_right_click)
        self.icon.connect("activate", self.on_left_click)

        self._start_hotkey_listener()

    def _start_hotkey_listener(self):
        def listen():
            try:
                from pynput import keyboard

                hotkey_str = normalize_hotkey(get_setting("hotkey") or "<ctrl>+k")

                def on_activate():
                    from gi.repository import GLib
                    import time
                    time.sleep(0.2)  # wait for hotkey keys to be fully released
                    GLib.idle_add(self.show_launcher)

                with keyboard.GlobalHotKeys({hotkey_str: on_activate}) as h:
                    h.join()
            except Exception as e:
                print(f"Hotkey listener error: {e}")

        t = threading.Thread(target=listen, daemon=True)
        t.start()

    def on_left_click(self, icon):
        self.show_launcher()

    def on_right_click(self, icon, button, time):
        menu = self.build_menu()
        menu.popup(None, None, Gtk.StatusIcon.position_menu, icon, button, time)

    def build_menu(self):
        menu = Gtk.Menu()

        item_oneliners = Gtk.MenuItem(label="One Liners")
        item_oneliners.connect("activate", self.open_oneliners)
        menu.append(item_oneliners)

        item_recipes = Gtk.MenuItem(label="Recipes")
        item_recipes.connect("activate", self.open_recipes)
        menu.append(item_recipes)

        item_connections = Gtk.MenuItem(label="Connections")
        item_connections.connect("activate", self.open_connections)
        menu.append(item_connections)

        menu.append(Gtk.SeparatorMenuItem())

        item_export = Gtk.MenuItem(label="Export Library")
        item_export.connect("activate", self.on_export)
        menu.append(item_export)

        item_import = Gtk.MenuItem(label="Import Library")
        item_import.connect("activate", self.on_import)
        menu.append(item_import)

        menu.append(Gtk.SeparatorMenuItem())

        item_settings = Gtk.MenuItem(label="Settings")
        item_settings.connect("activate", self.open_settings)
        menu.append(item_settings)

        menu.append(Gtk.SeparatorMenuItem())

        item_quit = Gtk.MenuItem(label="Quit")
        item_quit.connect("activate", self.quit)
        menu.append(item_quit)

        menu.show_all()
        return menu

    def show_launcher(self):
        if hasattr(self, '_launcher') and self._launcher and self._launcher.get_visible():
            self._launcher.present()
            return
        from decky.launcher import LauncherWindow
        self._launcher = LauncherWindow()
        self._launcher.show_all()

    def open_oneliners(self, _):
        from decky.ui.oneliners import PlaysWindow
        PlaysWindow().show_all()

    def open_recipes(self, _):
        from decky.ui.recipes import RecipesWindow
        RecipesWindow().show_all()

    def open_connections(self, _):
        from decky.ui.connections import ConnectionsWindow
        ConnectionsWindow().show_all()

    def open_settings(self, _):
        from decky.ui.settings import SettingsWindow
        SettingsWindow().show_all()

    def on_export(self, _):
        dialog = Gtk.FileChooserDialog(
            title="Export Library",
            action=Gtk.FileChooserAction.SAVE
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_SAVE, Gtk.ResponseType.OK
        )
        dialog.set_current_name("decky-library.json")
        if dialog.run() == Gtk.ResponseType.OK:
            export_data(dialog.get_filename())
        dialog.destroy()

    def on_import(self, _):
        dialog = Gtk.FileChooserDialog(
            title="Import Library",
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        f = Gtk.FileFilter()
        f.set_name("JSON files")
        f.add_pattern("*.json")
        dialog.add_filter(f)
        if dialog.run() == Gtk.ResponseType.OK:
            import_data(dialog.get_filename())
        dialog.destroy()

    def quit(self, _):
        Gtk.main_quit()

    def run(self):
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        Gtk.main()
