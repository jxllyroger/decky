# ui/recipes.py - Recipes modal

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from decky.db import get_recipes, save_recipe, delete_recipe, get_oneliners


class RecipesWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Recipes")
        self.set_default_size(500, 400)
        self.set_border_width(10)
        self.set_position(Gtk.WindowPosition.CENTER)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.add(vbox)

        # Recipe list
        self.store = Gtk.ListStore(str)  # name
        self.tree = Gtk.TreeView(model=self.store)
        col_name = Gtk.TreeViewColumn("Recipe", Gtk.CellRendererText(), text=0)
        self.tree.append_column(col_name)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.add(self.tree)
        vbox.pack_start(scroll, True, True, 0)

        # Buttons
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        vbox.pack_start(btn_box, False, False, 0)

        btn_add = Gtk.Button(label="Add")
        btn_add.connect("clicked", self.on_add)
        btn_box.pack_start(btn_add, False, False, 0)

        btn_edit = Gtk.Button(label="Edit")
        btn_edit.connect("clicked", self.on_edit)
        btn_box.pack_start(btn_edit, False, False, 0)

        btn_delete = Gtk.Button(label="Delete")
        btn_delete.connect("clicked", self.on_delete)
        btn_box.pack_start(btn_delete, False, False, 0)

        self.refresh()

    def refresh(self):
        self.store.clear()
        for r in get_recipes():
            self.store.append([r["name"]])

    def get_selected(self):
        model, treeiter = self.tree.get_selection().get_selected()
        if treeiter:
            return model[treeiter][0]
        return None

    def on_add(self, _):
        RecipeDialog(self, None).run_and_save()
        self.refresh()

    def on_edit(self, _):
        name = self.get_selected()
        if not name:
            return
        recipes = {r["name"]: r for r in get_recipes()}
        RecipeDialog(self, recipes.get(name)).run_and_save()
        self.refresh()

    def on_delete(self, _):
        name = self.get_selected()
        if not name:
            return
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Delete '{name}'?"
        )
        if dialog.run() == Gtk.ResponseType.YES:
            delete_recipe(name)
            self.refresh()
        dialog.destroy()


class RecipeDialog:
    def __init__(self, parent, recipe):
        self.dialog = Gtk.Dialog(
            title="Edit Recipe" if recipe else "Add Recipe",
            transient_for=parent,
            modal=True
        )
        self.dialog.set_default_size(500, 450)
        self.dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )

        box = self.dialog.get_content_area()
        box.set_spacing(8)
        box.set_border_width(15)

        # Name
        name_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        name_box.pack_start(Gtk.Label(label="Name:"), False, False, 0)
        self.entry_name = Gtk.Entry()
        self.entry_name.set_hexpand(True)
        if recipe:
            self.entry_name.set_text(recipe["name"])
        name_box.pack_start(self.entry_name, True, True, 0)
        box.pack_start(name_box, False, False, 0)

        # Two column layout: available | in recipe
        columns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.pack_start(columns, True, True, 0)

        # Available one liners
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        left.pack_start(Gtk.Label(label="Available"), False, False, 0)
        self.avail_store = Gtk.ListStore(str)
        self.avail_tree = Gtk.TreeView(model=self.avail_store)
        self.avail_tree.append_column(Gtk.TreeViewColumn("One Liner", Gtk.CellRendererText(), text=0))
        avail_scroll = Gtk.ScrolledWindow()
        avail_scroll.set_vexpand(True)
        avail_scroll.set_hexpand(True)
        avail_scroll.add(self.avail_tree)
        left.pack_start(avail_scroll, True, True, 0)
        columns.pack_start(left, True, True, 0)

        # Add/Remove buttons
        mid = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        mid.set_valign(Gtk.Align.CENTER)
        btn_add = Gtk.Button(label="→")
        btn_add.connect("clicked", self.add_to_recipe)
        btn_remove = Gtk.Button(label="←")
        btn_remove.connect("clicked", self.remove_from_recipe)
        mid.pack_start(btn_add, False, False, 0)
        mid.pack_start(btn_remove, False, False, 0)
        columns.pack_start(mid, False, False, 0)

        # In recipe
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        right.pack_start(Gtk.Label(label="In Recipe (ordered)"), False, False, 0)
        self.recipe_store = Gtk.ListStore(str)
        self.recipe_tree = Gtk.TreeView(model=self.recipe_store)
        self.recipe_tree.append_column(Gtk.TreeViewColumn("One Liner", Gtk.CellRendererText(), text=0))
        recipe_scroll = Gtk.ScrolledWindow()
        recipe_scroll.set_vexpand(True)
        recipe_scroll.set_hexpand(True)
        recipe_scroll.add(self.recipe_tree)
        right.pack_start(recipe_scroll, True, True, 0)

        # Up/Down buttons
        ud_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        btn_up = Gtk.Button(label="↑")
        btn_up.connect("clicked", self.move_up)
        btn_down = Gtk.Button(label="↓")
        btn_down.connect("clicked", self.move_down)
        ud_box.pack_start(btn_up, False, False, 0)
        ud_box.pack_start(btn_down, False, False, 0)
        right.pack_start(ud_box, False, False, 0)
        columns.pack_start(right, True, True, 0)

        # Populate
        all_oneliners = [ol["name"] for ol in get_oneliners()]
        in_recipe = recipe["oneliners"] if recipe else []

        for name in in_recipe:
            self.recipe_store.append([name])
        for name in all_oneliners:
            if name not in in_recipe:
                self.avail_store.append([name])

        self.dialog.show_all()

    def add_to_recipe(self, _):
        model, treeiter = self.avail_tree.get_selection().get_selected()
        if treeiter:
            name = model[treeiter][0]
            self.recipe_store.append([name])
            self.avail_store.remove(treeiter)

    def remove_from_recipe(self, _):
        model, treeiter = self.recipe_tree.get_selection().get_selected()
        if treeiter:
            name = model[treeiter][0]
            self.avail_store.append([name])
            self.recipe_store.remove(treeiter)

    def move_up(self, _):
        model, treeiter = self.recipe_tree.get_selection().get_selected()
        if treeiter:
            prev = model.iter_previous(treeiter)
            if prev:
                model.swap(treeiter, prev)

    def move_down(self, _):
        model, treeiter = self.recipe_tree.get_selection().get_selected()
        if treeiter:
            next_ = model.iter_next(treeiter)
            if next_:
                model.swap(treeiter, next_)

    def run_and_save(self):
        response = self.dialog.run()
        if response == Gtk.ResponseType.OK:
            name = self.entry_name.get_text().strip()
            oneliners = [self.recipe_store[i][0] for i in range(len(self.recipe_store))]
            if name:
                save_recipe(name, oneliners)
        self.dialog.destroy()
