# db.py - Database layer for Decky
# Single SQLite file at ~/.config/decky/decky.db

import sqlite3
import os

DB_DIR = os.path.expanduser("~/.config/decky")
DB_PATH = os.path.join(DB_DIR, "decky.db")

def get_conn():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_conn() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS oneliners (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT NOT NULL UNIQUE,
                command     TEXT NOT NULL,
                category    TEXT DEFAULT '',
                description TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS recipes (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS recipe_oneliners (
                recipe_id   INTEGER REFERENCES recipes(id) ON DELETE CASCADE,
                oneliner_id INTEGER REFERENCES oneliners(id) ON DELETE CASCADE,
                sort_order  INTEGER DEFAULT 0,
                PRIMARY KEY (recipe_id, oneliner_id)
            );

            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );
        """)
        defaults = [
            # App
            ("hotkey",          "<ctrl>+k"),
            ("autostart",       "false"),
            ("terminal",        "guake"),
            # Jumper
            ("jumper_enabled",    "false"),
            ("jumper_name",       "decky"),
            ("jumper_host",       "d"),
            ("jumper_timeout",    "2h"),
            ("jumper_remote_cmd", "kssh"),
        ]
        for key, value in defaults:
            conn.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (key, value)
            )

# --- One Liners ---
def get_oneliners():
    with get_conn() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM oneliners ORDER BY category, name")]

def save_oneliner(name, command, category="", description=""):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO oneliners (name, command, category, description) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(name) DO UPDATE SET command=excluded.command, category=excluded.category, description=excluded.description",
            (name, command, category, description)
        )

def delete_oneliner(name):
    with get_conn() as conn:
        conn.execute("DELETE FROM oneliners WHERE name=?", (name,))

# --- Recipes ---
def get_recipes():
    with get_conn() as conn:
        recipes = [dict(r) for r in conn.execute("SELECT * FROM recipes ORDER BY name")]
        for recipe in recipes:
            oneliners = conn.execute(
                "SELECT o.name FROM oneliners o "
                "JOIN recipe_oneliners ro ON o.id = ro.oneliner_id "
                "WHERE ro.recipe_id = ? ORDER BY ro.sort_order",
                (recipe["id"],)
            ).fetchall()
            recipe["oneliners"] = [o["name"] for o in oneliners]
        return recipes

def save_recipe(name, oneliner_names):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO recipes (name) VALUES (?) ON CONFLICT(name) DO NOTHING",
            (name,)
        )
        recipe_id = conn.execute("SELECT id FROM recipes WHERE name=?", (name,)).fetchone()["id"]
        conn.execute("DELETE FROM recipe_oneliners WHERE recipe_id=?", (recipe_id,))
        for i, oneliner_name in enumerate(oneliner_names):
            oneliner = conn.execute("SELECT id FROM oneliners WHERE name=?", (oneliner_name,)).fetchone()
            if oneliner:
                conn.execute(
                    "INSERT INTO recipe_oneliners (recipe_id, oneliner_id, sort_order) VALUES (?, ?, ?)",
                    (recipe_id, oneliner["id"], i)
                )

def delete_recipe(name):
    with get_conn() as conn:
        conn.execute("DELETE FROM recipes WHERE name=?", (name,))

# --- Settings ---
def get_setting(key):
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

def save_setting(key, value):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value)
        )


# --- Export / Import ---
def export_data(path):
    """Export all oneliners and recipes to a JSON file."""
    import json
    data = {
        "oneliners": get_oneliners(),
        "recipes": get_recipes()
    }
    with open(path, 'w') as f:
        json.dump(data, f, indent=4)

def import_data(path):
    """Import oneliners and recipes from a JSON file. Skips duplicates."""
    import json
    with open(path) as f:
        data = json.load(f)
    for ol in data.get("oneliners", []):
        save_oneliner(ol["name"], ol["command"], ol.get("category", ""), ol.get("description", ""))
    for r in data.get("recipes", []):
        save_recipe(r["name"], r.get("oneliners", []))
