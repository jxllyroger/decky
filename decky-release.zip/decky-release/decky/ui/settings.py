# ui/settings.py - Settings modal

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import os
import shutil

from decky.db import get_setting, save_setting
from decky.jumper import write_jumper, write_autostart

KNOWN_TERMINALS = [
    "guake", "xterm", "gnome-terminal", "xfce4-terminal",
    "konsole", "tilix", "alacritty", "kitty", "terminator"
]

def detect_terminal():
    env_terminal = os.environ.get("TERMINAL")
    if env_terminal and shutil.which(env_terminal):
        return env_terminal
    for term in KNOWN_TERMINALS:
        if shutil.which(term):
            return term
    return ""

class SettingsWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Settings")
        self.set_default_size(480, 420)
        self.set_border_width(15)
        self.set_position(Gtk.WindowPosition.CENTER)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.add(vbox)

        # --- App Section ---
        app_frame = Gtk.Frame(label="App")
        app_grid = Gtk.Grid()
        app_grid.set_row_spacing(10)
        app_grid.set_column_spacing(10)
        app_grid.set_border_width(10)
        app_frame.add(app_grid)
        vbox.pack_start(app_frame, False, False, 0)

        self.entry_hotkey   = self._row(app_grid, 0, "Hotkey:",   get_setting("hotkey")   or "<ctrl>+k")
        self.entry_terminal = self._row(app_grid, 1, "Terminal:", get_setting("terminal") or detect_terminal())

        lbl_autostart = Gtk.Label(label="Start on Login:", xalign=0)
        self.chk_autostart = Gtk.CheckButton()
        self.chk_autostart.set_active(get_setting("autostart") == "true")
        app_grid.attach(lbl_autostart,      0, 2, 1, 1)
        app_grid.attach(self.chk_autostart, 1, 2, 1, 1)

        # --- Jumper Section ---
        jmp_frame = Gtk.Frame(label="Jumper")
        jmp_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        jmp_outer.set_border_width(10)
        jmp_frame.add(jmp_outer)
        vbox.pack_start(jmp_frame, False, False, 0)

        toggle_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        toggle_box.pack_start(Gtk.Label(label="Enable Jumper:"), False, False, 0)
        self.chk_jumper = Gtk.CheckButton()
        self.chk_jumper.set_active(get_setting("jumper_enabled") == "true")
        self.chk_jumper.connect("toggled", self.on_jumper_toggled)
        toggle_box.pack_start(self.chk_jumper, False, False, 0)
        jmp_outer.pack_start(toggle_box, False, False, 0)

        self.jmp_grid = Gtk.Grid()
        self.jmp_grid.set_row_spacing(10)
        self.jmp_grid.set_column_spacing(10)
        jmp_outer.pack_start(self.jmp_grid, False, False, 0)

        self.entry_jmp_name    = self._row(self.jmp_grid, 0, "Function Name:", get_setting("jumper_name")       or "decky")
        self.entry_jmp_host    = self._row(self.jmp_grid, 1, "SSH Host:",      get_setting("jumper_host")       or "d")
        self.entry_jmp_timeout = self._row(self.jmp_grid, 2, "Cmd Timeout:",   get_setting("jumper_timeout")    or "2h")
        self.entry_jmp_rcmd    = self._row(self.jmp_grid, 3, "Remote Cmd:",    get_setting("jumper_remote_cmd") or "kssh")

        self.jmp_grid.set_sensitive(self.chk_jumper.get_active())

        # Save button
        btn_save = Gtk.Button(label="Save")
        btn_save.connect("clicked", self.save)
        vbox.pack_start(btn_save, False, False, 0)

    def _row(self, grid, row, label, value):
        lbl = Gtk.Label(label=label, xalign=0)
        entry = Gtk.Entry()
        entry.set_hexpand(True)
        entry.set_text(value)
        grid.attach(lbl,   0, row, 1, 1)
        grid.attach(entry, 1, row, 1, 1)
        return entry

    def on_jumper_toggled(self, widget):
        self.jmp_grid.set_sensitive(widget.get_active())

    def save(self, _):
        save_setting("hotkey",           self.entry_hotkey.get_text().strip())
        save_setting("terminal",         self.entry_terminal.get_text().strip())
        autostart = self.chk_autostart.get_active()
        save_setting("autostart",        "true" if autostart else "false")
        write_autostart(autostart)

        save_setting("jumper_enabled",   "true" if self.chk_jumper.get_active() else "false")
        save_setting("jumper_name",      self.entry_jmp_name.get_text().strip())
        save_setting("jumper_host",      self.entry_jmp_host.get_text().strip())
        save_setting("jumper_timeout",   self.entry_jmp_timeout.get_text().strip())
        save_setting("jumper_remote_cmd", self.entry_jmp_rcmd.get_text().strip())

        if self.chk_jumper.get_active():
            try:
                write_jumper()
            except Exception as e:
                err = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK, text=f"Failed to write jumper:\n{e}")
                err.run()
                err.destroy()
                return

        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text="Settings saved."
        )
        dialog.run()
        dialog.destroy()
        self.destroy()
