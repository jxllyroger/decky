# launcher.py - Ctrl+K floating search launcher

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk
import subprocess
import re
import time

from decky.db import get_oneliners, get_recipes, get_setting


def get_all_items():
    items = []
    for ol in get_oneliners():
        items.append({
            "label":       ol["name"],
            "category":    ol["category"] or "Uncategorized",
            "type":        "oneliner",
            "command":     ol["command"],
            "description": ol.get("description") or "",
        })
    for r in get_recipes():
        items.append({
            "label":    r["name"],
            "category": "Recipe",
            "type":     "recipe",
            "oneliners": r["oneliners"],
        })
    return items


def resolve_variables(command):
    variables = re.findall(r'\{\{(\w+)\}\}', command)
    if not variables:
        return command

    seen = set()
    unique_vars = []
    for v in variables:
        if v not in seen:
            seen.add(v)
            unique_vars.append(v)

    dialog = Gtk.Dialog(title="Fill in variables", modal=True)
    dialog.set_keep_above(True)
    dialog.set_default_size(380, 120 + len(unique_vars) * 50)
    dialog.add_buttons(
        Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
        Gtk.STOCK_OK, Gtk.ResponseType.OK
    )

    grid = Gtk.Grid()
    grid.set_row_spacing(10)
    grid.set_column_spacing(10)
    grid.set_border_width(15)

    entries = {}
    for i, var in enumerate(unique_vars):
        lbl = Gtk.Label(label=f"{var}:", xalign=0)
        entry = Gtk.Entry()
        entry.set_hexpand(True)
        grid.attach(lbl, 0, i, 1, 1)
        grid.attach(entry, 1, i, 1, 1)
        entries[var] = entry

    for var in unique_vars:
        entries[var].connect("activate", lambda w: dialog.response(Gtk.ResponseType.OK))

    dialog.get_content_area().add(grid)
    dialog.show_all()

    if unique_vars:
        entries[unique_vars[0]].grab_focus()

    response = dialog.run()
    if response != Gtk.ResponseType.OK:
        dialog.destroy()
        return None

    filled = command
    for var, entry in entries.items():
        filled = filled.replace(f"{{{{{var}}}}}", entry.get_text().strip())

    dialog.destroy()
    return filled


def get_terminal_windows():
    try:
        out = subprocess.check_output(["wmctrl", "-lx"], text=True).splitlines()
        terminal_classes = ["guake", "xterm", "gnome-terminal", "xfce4-terminal",
                            "konsole", "tilix", "alacritty", "kitty", "terminator"]
        windows = []
        for line in out:
            parts = line.split(None, 4)
            if len(parts) >= 4:
                wm_class = parts[2].lower()
                title = parts[4] if len(parts) > 4 else ""
                for tc in terminal_classes:
                    if tc in wm_class:
                        windows.append({"id": parts[0], "class": wm_class, "title": title})
                        break
        return windows
    except Exception:
        return []


def pick_window(windows):
    dialog = Gtk.Dialog(title="Which terminal?", modal=True)
    dialog.set_default_size(350, 200)
    dialog.add_buttons(
        Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
        Gtk.STOCK_OK, Gtk.ResponseType.OK
    )
    store = Gtk.ListStore(str, str)
    tree = Gtk.TreeView(model=store)
    tree.append_column(Gtk.TreeViewColumn("Window", Gtk.CellRendererText(), text=1))
    for w in windows:
        store.append([w["id"], w["title"] or w["class"]])
    scroll = Gtk.ScrolledWindow()
    scroll.set_vexpand(True)
    scroll.add(tree)
    dialog.get_content_area().add(scroll)
    dialog.show_all()

    selected = None
    if dialog.run() == Gtk.ResponseType.OK:
        model, treeiter = tree.get_selection().get_selected()
        if treeiter:
            wid = model[treeiter][0]
            selected = next((w for w in windows if w["id"] == wid), None)
    dialog.destroy()
    return selected


def fire_command(command):
    command = resolve_variables(command)
    if command is None:
        return

    terminal = get_setting("terminal") or "guake"
    windows = get_terminal_windows()

    if len(windows) > 1:
        win = pick_window(windows)
        if not win:
            return
        subprocess.Popen(["wmctrl", "-ia", win["id"]])
    elif len(windows) == 1:
        subprocess.Popen(["wmctrl", "-ia", windows[0]["id"]])

    if "guake" in terminal:
        subprocess.call(["guake", "--show"])

    clip = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
    clip.set_text(command, -1)
    clip.store()

    time.sleep(0.3)
    subprocess.call(["xdotool", "key", "--clearmodifiers", "ctrl+shift+v"])
    time.sleep(0.05)
    subprocess.call(["xdotool", "key", "Return"])


class LauncherWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Decky")
        self.set_default_size(650, 450)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(10)
        self.set_keep_above(True)
        self.set_decorated(False)

        self.connect("key-press-event", self.on_key_press)
        self.items = get_all_items()
        self.active_category = "All"

        # Main layout: sidebar + content
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.add(hbox)

        # --- Sidebar ---
        sidebar_scroll = Gtk.ScrolledWindow()
        sidebar_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sidebar_scroll.set_min_content_width(130)

        self.cat_store = Gtk.ListStore(str)
        self.cat_tree = Gtk.TreeView(model=self.cat_store)
        self.cat_tree.set_headers_visible(False)
        self.cat_tree.append_column(Gtk.TreeViewColumn("", Gtk.CellRendererText(), text=0))
        self.cat_tree.connect("cursor-changed", self.on_category_changed)
        sidebar_scroll.add(self.cat_tree)
        hbox.pack_start(sidebar_scroll, False, False, 0)

        # --- Right side ---
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        hbox.pack_start(vbox, True, True, 0)

        # Search
        self.search = Gtk.Entry()
        self.search.set_placeholder_text("Search, @category, #recipe, >raw command...")
        self.search.connect("changed", self.on_search_changed)
        self.search.connect("activate", self.on_activate)
        vbox.pack_start(self.search, False, False, 0)

        # Results
        self.store = Gtk.ListStore(str, str, str, str)  # label, category, type, description
        self.filter_store = self.store.filter_new()
        self.filter_store.set_visible_func(self.filter_func)

        self.tree = Gtk.TreeView(model=self.filter_store)
        self.tree.set_headers_visible(True)
        self.tree.append_column(Gtk.TreeViewColumn("Name", Gtk.CellRendererText(), text=0))
        self.tree.append_column(Gtk.TreeViewColumn("Category", Gtk.CellRendererText(), text=1))
        self.tree.append_column(Gtk.TreeViewColumn("Description", Gtk.CellRendererText(), text=3))
        self.tree.connect("row-activated", self.on_row_activated)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.add(self.tree)
        vbox.pack_start(scroll, True, True, 0)

        self.populate_categories()
        self.populate()
        self.search.grab_focus()

    def populate_categories(self):
        self.cat_store.clear()
        self.cat_store.append(["All"])
        self.cat_store.append(["Recipe"])

        cats = sorted(set(
            item["category"] for item in self.items
            if item["type"] == "oneliner" and item["category"] != "Uncategorized"
        ))
        for cat in cats:
            self.cat_store.append([cat])
        self.cat_store.append(["Uncategorized"])

        # Select "All" by default
        self.cat_tree.get_selection().select_path(Gtk.TreePath.new_first())

    def populate(self):
        self.store.clear()
        for item in self.items:
            self.store.append([item["label"], item["category"], item["type"], item.get("description", "")])

    def on_category_changed(self, tree):
        model, treeiter = tree.get_selection().get_selected()
        if treeiter:
            self.active_category = model[treeiter][0]
            self.filter_store.refilter()
            first = self.filter_store.get_iter_first()
            if first:
                self.tree.get_selection().select_iter(first)

    def filter_func(self, model, treeiter, data):
        query = self.search.get_text()
        label = model[treeiter][0].lower()
        category = model[treeiter][1].lower()
        item_type = model[treeiter][2]

        # Power user prefixes override sidebar
        if query.startswith("@"):
            return query[1:].lower() in category
        if query.startswith("#"):
            return item_type == "recipe" and query[1:].lower() in label
        if query.startswith(">"):
            return False  # raw command mode — hide all items

        # Sidebar category filter
        if self.active_category != "All":
            if category != self.active_category.lower():
                return False

        if query:
            return query.lower() in label or query.lower() in category

        return True

    def on_search_changed(self, _):
        self.filter_store.refilter()
        first = self.filter_store.get_iter_first()
        if first:
            self.tree.get_selection().select_iter(first)

    def on_activate(self, _):
        query = self.search.get_text()

        # Raw command mode
        if query.startswith(">"):
            cmd = query[1:].strip()
            if cmd:
                self.destroy()
                fire_command(cmd)
            return

        model, treeiter = self.tree.get_selection().get_selected()
        if treeiter:
            self.execute_item(model[treeiter][0])

    def on_row_activated(self, tree, path, column):
        model = tree.get_model()
        treeiter = model.get_iter(path)
        self.execute_item(model[treeiter][0])

    def execute_item(self, label):
        item = next((i for i in self.items if i["label"] == label), None)
        if not item:
            return

        self.destroy()

        if item["type"] == "oneliner":
            fire_command(item["command"])
        elif item["type"] == "recipe":
            for ol_name in item["oneliners"]:
                ol = next((i for i in self.items if i["label"] == ol_name and i["type"] == "oneliner"), None)
                if ol:
                    fire_command(ol["command"])

    def on_key_press(self, widget, event):
        if event.keyval == Gdk.KEY_Escape:
            self.destroy()
        return False
