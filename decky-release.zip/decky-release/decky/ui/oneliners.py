# ui/oneliners.py - One Liners modal

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

from decky.db import get_oneliners, save_oneliner, delete_oneliner


class PlaysWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="One Liners")
        self.set_default_size(500, 400)
        self.set_border_width(10)
        self.set_position(Gtk.WindowPosition.CENTER)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.add(vbox)

        # List
        self.store = Gtk.ListStore(str, str, str)  # name, category, description
        self.tree = Gtk.TreeView(model=self.store)

        col_name = Gtk.TreeViewColumn("Name", Gtk.CellRendererText(), text=0)
        col_cat = Gtk.TreeViewColumn("Category", Gtk.CellRendererText(), text=1)
        col_desc = Gtk.TreeViewColumn("Description", Gtk.CellRendererText(), text=2)
        self.tree.append_column(col_name)
        self.tree.append_column(col_cat)
        self.tree.append_column(col_desc)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.add(self.tree)
        vbox.pack_start(scroll, True, True, 0)

        # Buttons
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        vbox.pack_start(btn_box, False, False, 0)

        btn_add = Gtk.Button(label="Add")
        btn_add.connect("clicked", self.on_add)
        btn_box.pack_start(btn_add, False, False, 0)

        btn_edit = Gtk.Button(label="Edit")
        btn_edit.connect("clicked", self.on_edit)
        btn_box.pack_start(btn_edit, False, False, 0)

        btn_delete = Gtk.Button(label="Delete")
        btn_delete.connect("clicked", self.on_delete)
        btn_box.pack_start(btn_delete, False, False, 0)

        self.refresh()

    def refresh(self):
        self.store.clear()
        for ol in get_oneliners():
            self.store.append([ol["name"], ol["category"], ol.get("description", "")])

    def get_selected(self):
        model, treeiter = self.tree.get_selection().get_selected()
        if treeiter:
            return model[treeiter][0]
        return None

    def on_add(self, _):
        OnelinerDialog(self, None).run_and_save()
        self.refresh()

    def on_edit(self, _):
        name = self.get_selected()
        if not name:
            return
        oneliners = {ol["name"]: ol for ol in get_oneliners()}
        OnelinerDialog(self, oneliners.get(name)).run_and_save()
        self.refresh()

    def on_delete(self, _):
        name = self.get_selected()
        if not name:
            return
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Delete '{name}'?"
        )
        if dialog.run() == Gtk.ResponseType.YES:
            delete_oneliner(name)
            self.refresh()
        dialog.destroy()


class OnelinerDialog:
    def __init__(self, parent, oneliner):
        self.dialog = Gtk.Dialog(
            title="Edit One Liner" if oneliner else "Add One Liner",
            transient_for=parent,
            modal=True
        )
        self.dialog.set_default_size(400, 200)
        self.dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )

        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(10)
        grid.set_border_width(15)

        lbl_name = Gtk.Label(label="Name:", xalign=0)
        self.entry_name = Gtk.Entry()
        self.entry_name.set_hexpand(True)

        lbl_command = Gtk.Label(label="Command:", xalign=0)
        self.entry_command = Gtk.TextView()
        self.entry_command.set_hexpand(True)
        self.entry_command.set_vexpand(True)
        self.entry_command.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        cmd_scroll = Gtk.ScrolledWindow()
        cmd_scroll.set_min_content_height(80)
        cmd_scroll.set_hexpand(True)
        cmd_scroll.add(self.entry_command)

        lbl_category = Gtk.Label(label="Category:", xalign=0)
        self.entry_category = Gtk.Entry()
        self.entry_category.set_hexpand(True)

        lbl_description = Gtk.Label(label="Description:", xalign=0)
        self.entry_description = Gtk.Entry()
        self.entry_description.set_hexpand(True)
        self.entry_description.set_placeholder_text("Usage, args, examples...")

        if oneliner:
            self.entry_name.set_text(oneliner["name"])
            self.entry_command.get_buffer().set_text(oneliner["command"])
            self.entry_category.set_text(oneliner["category"] or "")
            self.entry_description.set_text(oneliner.get("description") or "")

        grid.attach(lbl_name, 0, 0, 1, 1)
        grid.attach(self.entry_name, 1, 0, 1, 1)
        grid.attach(lbl_command, 0, 1, 1, 1)
        grid.attach(cmd_scroll, 1, 1, 1, 1)
        grid.attach(lbl_category, 0, 2, 1, 1)
        grid.attach(self.entry_category, 1, 2, 1, 1)
        grid.attach(lbl_description, 0, 3, 1, 1)
        grid.attach(self.entry_description, 1, 3, 1, 1)

        self.dialog.get_content_area().add(grid)
        self.dialog.show_all()

    def run_and_save(self):
        response = self.dialog.run()
        if response == Gtk.ResponseType.OK:
            name = self.entry_name.get_text().strip()
            buf = self.entry_command.get_buffer()
            command = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False).strip()
            category = self.entry_category.get_text().strip()
            description = self.entry_description.get_text().strip()
            if name and command:
                save_oneliner(name, command, category, description)
        self.dialog.destroy()
