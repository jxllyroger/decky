# ui/connections.py - SSH Config manager
# Reads and writes ~/.ssh/config directly

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import os
import re

SSH_CONFIG = os.path.expanduser("~/.ssh/config")


def parse_ssh_config():
    """Parse ~/.ssh/config into a list of host blocks."""
    hosts = []
    if not os.path.exists(SSH_CONFIG):
        return hosts

    current = None
    with open(SSH_CONFIG) as f:
        for line in f:
            line = line.rstrip()
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue
            m = re.match(r'^[Hh]ost\s+(.+)$', stripped)
            if m:
                if current:
                    hosts.append(current)
                current = {"Host": m.group(1), "_options": []}
            elif current is not None:
                m2 = re.match(r'^(\S+)\s+(.+)$', stripped)
                if m2:
                    current["_options"].append((m2.group(1), m2.group(2)))
    if current:
        hosts.append(current)
    return hosts


def write_ssh_config(hosts):
    """Write host blocks back to ~/.ssh/config with backup and validation."""
    import tempfile
    import shutil
    import subprocess

    os.makedirs(os.path.dirname(SSH_CONFIG), exist_ok=True)

    # Build the new config content
    lines = []
    for i, host in enumerate(hosts):
        if i > 0:
            lines.append("")
        lines.append(f"Host {host['Host']}")
        for key, val in host.get("_options", []):
            lines.append(f"   {key} {val}")
    content = "\n".join(lines) + "\n"

    # Write to a temp file and validate first
    with tempfile.NamedTemporaryFile(mode='w', suffix='.ssh_config', delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            ["ssh", "-F", tmp_path, "-G", "localhost"],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            os.unlink(tmp_path)
            raise ValueError(f"SSH config validation failed:\n{result.stderr}")
    except FileNotFoundError:
        # ssh not found, skip validation
        pass

    # Backup existing config
    backup_path = SSH_CONFIG + ".decky.bak"
    if os.path.exists(SSH_CONFIG):
        shutil.copy2(SSH_CONFIG, backup_path)

    # Write the validated config
    try:
        with open(SSH_CONFIG, 'w') as f:
            f.write(content)
        os.unlink(tmp_path)
    except Exception as e:
        # Restore backup on failure
        if os.path.exists(backup_path):
            shutil.copy2(backup_path, SSH_CONFIG)
        os.unlink(tmp_path)
        raise e


class ConnectionsWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="SSH Config")
        self.set_default_size(550, 400)
        self.set_border_width(10)
        self.set_position(Gtk.WindowPosition.CENTER)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.add(vbox)

        self.store = Gtk.ListStore(str, str, str)  # Host, HostName, User
        self.tree = Gtk.TreeView(model=self.store)
        self.tree.append_column(Gtk.TreeViewColumn("Host", Gtk.CellRendererText(), text=0))
        self.tree.append_column(Gtk.TreeViewColumn("HostName", Gtk.CellRendererText(), text=1))
        self.tree.append_column(Gtk.TreeViewColumn("User", Gtk.CellRendererText(), text=2))

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.add(self.tree)
        vbox.pack_start(scroll, True, True, 0)

        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        vbox.pack_start(btn_box, False, False, 0)

        btn_add = Gtk.Button(label="Add")
        btn_add.connect("clicked", self.on_add)
        btn_box.pack_start(btn_add, False, False, 0)

        btn_edit = Gtk.Button(label="Edit")
        btn_edit.connect("clicked", self.on_edit)
        btn_box.pack_start(btn_edit, False, False, 0)

        btn_delete = Gtk.Button(label="Delete")
        btn_delete.connect("clicked", self.on_delete)
        btn_box.pack_start(btn_delete, False, False, 0)

        self.refresh()

    def refresh(self):
        self.store.clear()
        for host in parse_ssh_config():
            opts = dict(host["_options"])
            self.store.append([
                host["Host"],
                opts.get("HostName", ""),
                opts.get("User", "")
            ])

    def get_selected_host(self):
        model, treeiter = self.tree.get_selection().get_selected()
        if treeiter:
            return model[treeiter][0]
        return None

    def on_add(self, _):
        HostDialog(self, None).run_and_save()
        self.refresh()

    def on_edit(self, _):
        name = self.get_selected_host()
        if not name:
            return
        hosts = {h["Host"]: h for h in parse_ssh_config()}
        HostDialog(self, hosts.get(name)).run_and_save()
        self.refresh()

    def on_delete(self, _):
        name = self.get_selected_host()
        if not name:
            return
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Delete Host '{name}' from SSH config?"
        )
        if dialog.run() == Gtk.ResponseType.YES:
            try:
                hosts = [h for h in parse_ssh_config() if h["Host"] != name]
                write_ssh_config(hosts)
                self.refresh()
            except Exception as e:
                err = Gtk.MessageDialog(transient_for=self, message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK, text=f"Failed to save SSH config:\n{e}")
                err.run()
                err.destroy()
        dialog.destroy()


class HostDialog:
    def __init__(self, parent, host):
        self.original_name = host["Host"] if host else None
        self.dialog = Gtk.Dialog(
            title="Edit Host" if host else "Add Host",
            transient_for=parent,
            modal=True
        )
        self.dialog.set_default_size(460, 520)
        self.dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )

        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(10)
        grid.set_border_width(15)

        opts = dict(host["_options"]) if host else {}

        fields = [
            ("Host:",                  "Host",                   host["Host"] if host else ""),
            ("HostName:",              "HostName",               opts.get("HostName", "")),
            ("User:",                  "User",                   opts.get("User", "")),
            ("Port:",                  "Port",                   opts.get("Port", "22")),
            ("IdentityFile:",          "IdentityFile",           opts.get("IdentityFile", "")),
            ("ProxyJump:",             "ProxyJump",              opts.get("ProxyJump", "")),
            ("ControlMaster:",         "ControlMaster",          opts.get("ControlMaster", "")),
            ("ControlPath:",           "ControlPath",            opts.get("ControlPath", "")),
            ("ControlPersist:",        "ControlPersist",         opts.get("ControlPersist", "")),
            ("ServerAliveInterval:",   "ServerAliveInterval",    opts.get("ServerAliveInterval", "")),
            ("RemoteCommand:",         "RemoteCommand",          opts.get("RemoteCommand", "")),
        ]

        self.entries = {}
        for i, (label, key, default) in enumerate(fields):
            lbl = Gtk.Label(label=label, xalign=0)
            entry = Gtk.Entry()
            entry.set_hexpand(True)
            entry.set_text(default)
            grid.attach(lbl, 0, i, 1, 1)
            grid.attach(entry, 1, i, 1, 1)
            self.entries[key] = entry

        self.dialog.get_content_area().add(grid)
        self.dialog.show_all()

    def run_and_save(self):
        response = self.dialog.run()
        if response == Gtk.ResponseType.OK:
            host_name = self.entries["Host"].get_text().strip()
            if not host_name:
                self.dialog.destroy()
                return

            options = []
            for key, entry in self.entries.items():
                if key == "Host":
                    continue
                val = entry.get_text().strip()
                if val:
                    options.append((key, val))

            new_host = {"Host": host_name, "_options": options}

            hosts = parse_ssh_config()
            replaced = False
            for i, h in enumerate(hosts):
                if h["Host"] == self.original_name:
                    hosts[i] = new_host
                    replaced = True
                    break
            if not replaced:
                hosts.append(new_host)

            try:
                write_ssh_config(hosts)
            except Exception as e:
                err = Gtk.MessageDialog(transient_for=self.dialog, message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK, text=f"Failed to save SSH config:\n{e}")
                err.run()
                err.destroy()
                return
        self.dialog.destroy()
