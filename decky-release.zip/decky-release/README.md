# Decky

SSH connection manager and command launcher.

## Install

```bash
chmod +x install.sh && ./install.sh
```

## Usage

- Right click tray icon — manage One Liners, Recipes, Connections, Settings
- Ctrl+K — open the launcher
- Type to search, Enter to fire
- @category — filter by category
- #recipe — filter by recipes
- >command — run a raw command without saving

## Jumper

Enable in Settings to generate your SSH workflow functions.
Saves to ~/.bashrc.d/<name> — run `source ~/.bashrc` to activate.

## CLI

`scripts` — list all one liners and recipes
`scripts <name>` — run a one liner or recipe
`scripts <name> <args>` — run with args
